basta mao rana
